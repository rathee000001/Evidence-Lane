# Build Plan

Env14 exact base → overlay Env15 schema/state-travel delta → restore 14 sectors → append MMD deltas → render SVG/PNG → validate DB/hash/ZIP.
