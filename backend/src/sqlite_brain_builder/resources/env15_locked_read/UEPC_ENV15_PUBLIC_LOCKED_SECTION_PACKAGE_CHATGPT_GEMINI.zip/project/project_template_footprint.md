# Env15 Project Template Footprint

- SQLite schema objects: 119
- Universal project sectors packaged: 14
- Automatic write sectors: 1 (`chat_lineage`)
- Explicit one-turn mutation sectors: 13
- Non-lineage project payload: EXPECTED_EMPTY
- Env mutation allowed: false
- UOP override allowed: false
