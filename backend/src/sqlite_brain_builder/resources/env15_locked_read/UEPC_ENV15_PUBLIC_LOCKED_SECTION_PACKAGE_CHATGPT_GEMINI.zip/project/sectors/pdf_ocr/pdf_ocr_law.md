# Env15 PDF / OCR Sector Law

Sector ID: `PDF_OCR`  
State: `EXPECTED_EMPTY`  
Default access: read-only.  
Mutation: allowed only when the user explicitly names this sector and grants one-turn mutation permission.  
After commit: write a mutation receipt, update the sector head, and relock immediately.  
Automatic write: forbidden. `chat_lineage` remains the only automatic append-write sector.

Purpose: PDF extraction and OCR review lane.
