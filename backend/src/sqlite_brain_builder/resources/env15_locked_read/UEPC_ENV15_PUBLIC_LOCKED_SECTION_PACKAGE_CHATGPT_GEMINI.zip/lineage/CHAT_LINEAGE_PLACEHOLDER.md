<!-- Optional: place an old chat lineage MD here only when creating a project-history package. Clean Env12 baseline does not include raw lineage content. -->
