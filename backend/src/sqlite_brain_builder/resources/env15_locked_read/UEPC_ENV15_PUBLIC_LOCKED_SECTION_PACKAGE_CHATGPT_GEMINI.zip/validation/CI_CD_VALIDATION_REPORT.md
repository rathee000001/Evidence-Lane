# UEPC Env15 Corrected Build Validation Report

Generated: 2026-07-10T14:52:04Z

- PASS: 68
- FAIL: 0
- Outer ZIP SHA-256: computed after export; external by hash law

## Core correction

- Exact Env14 Env/UOP/Project MMD sources are contained as unmodified base text in the Env15 MMD files.
- Env15 nodes/edges are additive.
- All 14 project sectors are packaged.
- Env/UOP/Project SVG and PNG renders exist and are generated from the packaged MMD files.

## Checks

| Check | Status | Detail |
|---|---|---|
| Env14 baseline ZIP CRC | PASS |  |
| ENV SQLite preserves all Env14 tables/views | PASS | missing=[] |
| UOP SQLite preserves all Env14 tables/views | PASS | missing=[] |
| PROJECT SQLite preserves all Env14 tables/views | PASS | missing=[] |
| SQLite integrity env/env_sqlite.sqlite | PASS | ok |
| Foreign keys env/env_sqlite.sqlite | PASS | [] |
| SQLite integrity project/project_template.sqlite | PASS | ok |
| Foreign keys project/project_template.sqlite | PASS | [] |
| SQLite integrity project/sectors/artifacts/artifacts_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/artifacts/artifacts_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/brain_loader/brain_loader_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/brain_loader/brain_loader_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/chat_lineage/chat_lineage_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/chat_lineage/chat_lineage_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/custom/custom_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/custom/custom_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/data_excel/data_excel_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/data_excel/data_excel_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/docs/docs_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/docs/docs_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/github_code/github_code_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/github_code/github_code_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/images_ocr/images_ocr_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/images_ocr/images_ocr_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/local_code/local_code_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/local_code/local_code_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/pdf_ocr/pdf_ocr_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/pdf_ocr/pdf_ocr_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/ppt/ppt_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/ppt/ppt_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/project_engulf/project_engulf_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/project_engulf/project_engulf_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/research/research_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/research/research_sector_v001.sqlite | PASS | [] |
| SQLite integrity project/sectors/sqlite_brain/sqlite_brain_sector_v001.sqlite | PASS | ok |
| Foreign keys project/sectors/sqlite_brain/sqlite_brain_sector_v001.sqlite | PASS | [] |
| SQLite integrity uop/uop_sqlite.sqlite | PASS | ok |
| Foreign keys uop/uop_sqlite.sqlite | PASS | [] |
| env exact Env14 MMD base retained | PASS |  |
| env MMD no shrink | PASS | {'bytes': 12406, 'lines': 257, 'arrows': 199, 'node_like_tokens': 183, 'sha256': '1a60dce7c8b44595e74280fec7d8199801c6d8ad7c80d566518225e1d0981dfc'} -> {'bytes': 16835, 'lines': 350, 'arrows': 265, 'node_like_tokens': 252, 'sha256': '360c9878658106a24cfe60e0cdd98bb95ea8baabb7229c84c9d9163f397981f1'} |
| env SVG exists | PASS |  |
| env PNG exists | PASS |  |
| uop exact Env14 MMD base retained | PASS |  |
| uop MMD no shrink | PASS | {'bytes': 2541, 'lines': 53, 'arrows': 39, 'node_like_tokens': 40, 'sha256': '1382fcbaf612aa451a792d303de55c9b922b6e8319bdda230de679532d1ff8ff'} -> {'bytes': 4178, 'lines': 90, 'arrows': 61, 'node_like_tokens': 65, 'sha256': '7d9a51f7b29d26b2b7ab120a08d7cf504ab86c2fefe709b9c2681e32accd1189'} |
| uop SVG exists | PASS |  |
| uop PNG exists | PASS |  |
| project exact Env14 MMD base retained | PASS |  |
| project MMD no shrink | PASS | {'bytes': 2812, 'lines': 54, 'arrows': 40, 'node_like_tokens': 53, 'sha256': '2838ddd329bbaf1b4ef89210458aed6e753707c655a7bd76fdc16e7507dd15c4'} -> {'bytes': 6753, 'lines': 147, 'arrows': 112, 'node_like_tokens': 113, 'sha256': '43fe031e2e915b5780c00c49d32d7ea889b2115017bb90b90df3acf0c2634007'} |
| project SVG exists | PASS |  |
| project PNG exists | PASS |  |
| All 14 sector directories present | PASS |  |
| All 14 sector SQLite files present | PASS |  |
| Project sector registry contains 14 rows | PASS | [('CHAT_LINEAGE', 'AUTO_APPEND_ONLY_RW', 1, 0), ('GITHUB_CODE', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('LOCAL_CODE', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('SQLITE_BRAIN', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('DOCS', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('DATA_EXCEL', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('PDF_OCR', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('PPT', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('IMAGES_OCR', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('ARTIFACTS', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('CUSTOM', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('BRAIN_LOADER', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('RESEARCH', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('PROJECT_ENGULF', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1)] |
| Only chat_lineage auto-write | PASS | [('CHAT_LINEAGE', 'AUTO_APPEND_ONLY_RW', 1, 0), ('GITHUB_CODE', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('LOCAL_CODE', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('SQLITE_BRAIN', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('DOCS', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('DATA_EXCEL', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('PDF_OCR', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('PPT', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('IMAGES_OCR', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('ARTIFACTS', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('CUSTOM', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('BRAIN_LOADER', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('RESEARCH', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('PROJECT_ENGULF', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1)] |
| Other 13 sectors explicit grant | PASS | [('CHAT_LINEAGE', 'AUTO_APPEND_ONLY_RW', 1, 0), ('GITHUB_CODE', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('LOCAL_CODE', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('SQLITE_BRAIN', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('DOCS', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('DATA_EXCEL', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('PDF_OCR', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('PPT', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('IMAGES_OCR', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('ARTIFACTS', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('CUSTOM', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('BRAIN_LOADER', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('RESEARCH', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1), ('PROJECT_ENGULF', 'EXPLICIT_ONE_TURN_MUTATION', 0, 1)] |
| Chat lineage T002 committed | PASS |  |
| Canonical lineage head advanced | PASS |  |
| Append-only triggers present | PASS |  |
| Append-only UPDATE physically blocked | PASS |  |
| Safe FTS wrapper present | PASS |  |
| Credit token ledger prompt 2 present | PASS |  |
| Corrected Codex handoff present | PASS |  |
| Final ZIP CRC | PASS |  |
| PNG ZIP_STORED env/env_mmd.png | PASS | 0/1234865/1234865 |
| PNG ZIP_STORED project/project_topology_template.png | PASS | 0/370177/370177 |
| PNG ZIP_STORED uop/uop_mmd.png | PASS | 0/245459/245459 |
| Internal hash manifest verification | PASS | [] |
| Payload tree hash verification | PASS | 198139f6c9a6ea2724920bda7133c6386129ed7b74371e76da33460c7f081aef vs 198139f6c9a6ea2724920bda7133c6386129ed7b74371e76da33460c7f081aef |
