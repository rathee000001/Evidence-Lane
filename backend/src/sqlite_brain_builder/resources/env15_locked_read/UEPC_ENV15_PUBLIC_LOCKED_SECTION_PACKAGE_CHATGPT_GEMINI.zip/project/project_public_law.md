# Env15 Public Project Law — Full Sector Preservation

Updated: 2026-07-10T14:52:04Z

Env14 project template law and all future lane placeholders remain the base. Env15 adds state-travel, full sector packaging, code chunk-index contracts, legacy carry-forward, and research ledger behavior without removing any Env14 project node or lane.

## Sector boundary

All 14 universal project sectors are packaged.

- `chat_lineage`: automatic append-only read/write.
- Other 13 sectors: read-only by default; writable only when the user explicitly names the target sector and grants a one-turn mutation.
- After a granted write: receipt + hash + immediate relock.
- Project template/router/base never becomes the normal turn-write lane.
- Env and UOP never receive normal turn data.

## Legacy carry-forward

On first flash, an older Env active project-write section is copied without source mutation into the chat-lineage legacy mirror and registered with its originating sector.

## Clean state

Non-lineage sectors are schema-ready and expected empty. Their existence is not project population.
