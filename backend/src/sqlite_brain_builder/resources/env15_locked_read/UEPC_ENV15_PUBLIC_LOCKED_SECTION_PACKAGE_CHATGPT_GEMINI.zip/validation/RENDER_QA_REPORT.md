# Env15 Full Render QA

Updated: 2026-07-10T14:52:04Z

| Section | Env14 bytes/lines/arrows/nodes | Env15 bytes/lines/arrows/nodes | Exact base present | No-shrink | PNG dimensions |
|---|---:|---:|---|---|---:|
| ENV | 12406/257/199/183 | 16835/350/265/252 | YES | PASS | 15979×1999 |
| UOP | 2541/53/39/40 | 4178/90/61/65 | YES | PASS | 5099×689 |
| PROJECT | 2812/54/40/53 | 6753/147/112/113 | YES | PASS | 5216×1212 |
