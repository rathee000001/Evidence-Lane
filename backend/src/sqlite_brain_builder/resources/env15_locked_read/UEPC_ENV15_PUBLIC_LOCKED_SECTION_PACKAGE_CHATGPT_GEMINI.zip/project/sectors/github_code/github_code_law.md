# Env15 GitHub Code Sector Law

Sector ID: `GITHUB_CODE`  
State: `EXPECTED_EMPTY`  
Default access: read-only.  
Mutation: allowed only when the user explicitly names this sector and grants one-turn mutation permission.  
After commit: write a mutation receipt, update the sector head, and relock immediately.  
Automatic write: forbidden. `chat_lineage` remains the only automatic append-write sector.

Purpose: Full Git history + working-tree snapshot.
