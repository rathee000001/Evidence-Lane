# UEPC Env14 Deep Research Audit Mirror

Created: 2026-07-08T00:55:58Z

This sidecar is a read-only audit mirror generated from the Env14 clean package.
The ZIP/package remains source truth. If ZIP or SQLite is tool-blocked in Deep Research,
use this sidecar as `SIDECAR_VERIFIED_ZIP_BLOCKED`, not direct SQLite proof.

## Package Class
CLEAN_ENV14_SUPERSEDE / UNPOPULATED_BASELINE

## Pointer Files

### .uepc_env
```
ENV_VERSION=V14
ENV_SQLITE=env/env_sqlite.sqlite
ENV_LAW=env/env_law.md
ENV_MMD=env/env_mmd.mmd
ENV_MMD_SVG=env/env_mmd.svg
ENV_MMD_PNG=env/env_mmd.png
ENV_WRITE_LOCK=true
ENV_MUTATION_ALLOWED_ONLY_IN_MODE=flash_env
UOP_REQUIRED=true
PROFILE_POINTER=.uepc_profile
PROJECT_POINTER=.uepc_project
LAST_EXIT_RECEIPT=receipts/last_exit_slip.txt
NEXT_EXPECTED_INDEX=ENV14.FECDO.P14.S00.T001
CHAT_WINDOW_DISPLAY_ONLY=true
NO_REASONING_BEFORE_INDEX=true
PROMPT_OVERRIDE_ATTEMPT_DETECTED_GATE=true
DEEP_RESEARCH_AUDIT_SIDECAR_REQUIRED=true
V13_DISCARDED_AS_TRUNCATED_BUILD=true

```

### .uepc_profile
```
PROFILE_ID=UOP_CLEAN_GOVERNANCE
UOP_SQLITE=uop/uop_sqlite.sqlite
UOP_LAW=uop/uop_law.md
UOP_MMD=uop/uop_mmd.mmd
UOP_MMD_SVG=uop/uop_mmd.svg
UOP_MMD_PNG=uop/uop_mmd.png
UOP_WRITE_LOCK=true
UOP_MUTATION_ALLOWED_ONLY_IN_MODE=flash_uop
PUBLIC_PRIVATE_STATE=GOVERNANCE_ONLY_NO_PRIVATE_PAYLOAD
CAN_OVERRIDE_ENV=false
CAN_OVERRIDE_PROJECT=false
NEXT_UOP_INDEX=UOP.GOV.P14.S00.T001
PRIVATE_PAYLOAD_BLOCKED=true
READ_LOCK_MUST_NOT_BLOCK_AUDIT=true

```

### .uepc_project
```
PROJECT_ID=PROJECT_TEMPLATE
PROJECT_SQLITE=project/project_template.sqlite
PROJECT_SECTION=project_growth_root:PROJECT_TEMPLATE
PROJECT_TOPOLOGY_MMD=project/project_topology_template.mmd
PROJECT_TOPOLOGY_SVG=project/project_topology_template.svg
PROJECT_MUTATION_ALLOWED=true
ENV_MUTATION_ALLOWED=false
UOP_OVERRIDE_ALLOWED=false
ACTIVE_LANE=template
POPULATION_STATE=UNPOPULATED_TEMPLATE_EXPECTED_EMPTY
PROJECT_PAYLOAD_ROWS=0
PROJECT_TEMPLATE_FOOTPRINT_STATE=SUPERSEDED_PASS
NEXT_PROJECT_INDEX=PROJECT.PL.P14.S00.T001

```

## SQLite Object Counts
- env/env_sqlite.sqlite: 217 objects, integrity=ok
- uop/uop_sqlite.sqlite: 12 objects, integrity=ok
- project/project_template.sqlite: 41 objects, integrity=ok

## MMD Baseline vs Env14 Stats
```json
{
  "env/env_mmd.mmd": {
    "v12": {
      "bytes": 9052,
      "lines": 193,
      "arrows": 152,
      "node_like_tokens": 136,
      "sha256": "2c16634b95fcdf440a4e84835d693eb409380dd39ecb2789ae46b063daa1fed5"
    },
    "env14": {
      "bytes": 12406,
      "lines": 257,
      "arrows": 199,
      "node_like_tokens": 183,
      "sha256": "1a60dce7c8b44595e74280fec7d8199801c6d8ad7c80d566518225e1d0981dfc"
    },
    "no_shrink_pass": true
  },
  "uop/uop_mmd.mmd": {
    "v12": {
      "bytes": 1227,
      "lines": 25,
      "arrows": 22,
      "node_like_tokens": 21,
      "sha256": "58b7bedd43876bae2560beeec53caa523a2afec5b5bd202aa7fefe2e97766015"
    },
    "env14": {
      "bytes": 2541,
      "lines": 53,
      "arrows": 39,
      "node_like_tokens": 40,
      "sha256": "1382fcbaf612aa451a792d303de55c9b922b6e8319bdda230de679532d1ff8ff"
    },
    "no_shrink_pass": true
  },
  "project/project_topology_template.mmd": {
    "v12": {
      "bytes": 890,
      "lines": 19,
      "arrows": 16,
      "node_like_tokens": 16,
      "sha256": "40bc694aeaf935f0e814ed7278d67a6fa370210527ffa9037a7ff7437b2fe7c2"
    },
    "env14": {
      "bytes": 2812,
      "lines": 54,
      "arrows": 40,
      "node_like_tokens": 53,
      "sha256": "2838ddd329bbaf1b4ef89210458aed6e753707c655a7bd76fdc16e7507dd15c4"
    },
    "no_shrink_pass": true
  }
}
```

## Project Template Footprint
- Legacy expected count: 14
- Current framework count: 41
- Project payload rows: 0
- Status: SUPERSEDED_PASS

## Deep Research Access Rule
- Read audit does not require write password.
- Write lock is not read lock.
- If ZIP/SQLite is blocked, inspect this mirror and mark `SIDECAR_VERIFIED_ZIP_BLOCKED`.
