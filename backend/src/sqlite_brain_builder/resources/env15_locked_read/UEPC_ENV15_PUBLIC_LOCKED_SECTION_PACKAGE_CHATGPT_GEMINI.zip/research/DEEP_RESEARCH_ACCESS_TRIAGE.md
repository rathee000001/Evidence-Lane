DIRECT_ZIP_VERIFIED if ZIP/SQLite inspectable; SIDECAR_VERIFIED_ZIP_BLOCKED if sidecar only; BLOCKED otherwise. Read-only audit never requires write passwords.
