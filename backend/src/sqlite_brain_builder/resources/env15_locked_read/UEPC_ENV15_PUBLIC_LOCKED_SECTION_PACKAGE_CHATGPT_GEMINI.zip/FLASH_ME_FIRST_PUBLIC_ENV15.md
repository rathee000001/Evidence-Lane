# UEPC-ENV15-FLASH-BOOT-CORRECTED-001

**Mode:** `flash_env + validation + project_state_travel`

I uploaded one Env15 public locked package.

Read `.uepc_env`, `.uepc_profile`, `.uepc_project`, `env/env_sqlite.sqlite`, `uop/uop_sqlite.sqlite`, `project/project_template.sqlite`, `project/PROJECT_SECTOR_REGISTRY.json`, the latest chat-lineage head, manifests, receipts, and MMD lock registry before reasoning.

Hard laws:

- Env, UOP, project base, and all project sectors are preserved.
- Chat lineage is the only automatic append-write sector.
- The other 13 sectors require an explicit user-named one-turn mutation grant and relock after commit.
- Scan any older Env active project-write section and mirror it into chat-lineage legacy carry-forward without mutating the old package.
- `CHAT_LINEAGE_AUTO_APPEND_DEFAULT=true`.
- `LEGACY_PROJECT_SECTION_SCAN_DEFAULT=true`.
- `PROJECT_CARRY_FORWARD_TO_CHAT_LINEAGE_DEFAULT=true`.
- Exact prompt, exact visible response, links, receipts, hash chain, and lineage head must be recorded in AUTO mode.
- An explicit read-only/no-change audit sets `WRITEBACK_POLICY=DISABLED_READ_ONLY_AUDIT`.
- Env14 MMD source is the base of all three Env15 MMDs; missing base text, MMD shrink, missing SVG, or missing PNG is a failure.
- No hidden chain-of-thought storage.
- No raw secrets.

Run a compact entry slip and continue from the latest valid lineage head.
