Env14 clean supersede one-upload runpack.

Use FLASH_ME_FIRST_SINGLE_PROMPT.txt.
V13 is discarded. V12 was migrated forward without embedding the old ZIP.
Env/UOP/project MMDs are full end-to-end source maps.
SVG is the primary visual QA render.
