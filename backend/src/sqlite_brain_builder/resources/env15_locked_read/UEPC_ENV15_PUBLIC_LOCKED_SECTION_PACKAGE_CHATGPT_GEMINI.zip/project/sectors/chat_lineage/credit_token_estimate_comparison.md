# Credit Token Estimate Comparison

## Research Estimate Formula

Definitions:
- B_raw = estimated bytes of raw source/database/project material a naive method would need to paste or keep in-context.
- B_query = estimated bytes of relevant SQLite rows/chunks/files selected by the env method.
- T_prompt = estimated tokens in current user prompt.
- T_receipt = estimated tokens for entry/exit/visible route summary.
- T_overhead = fixed schema/query/tool overhead tokens.
- C_eff = effective safe context budget for the model/task.
- R_complexity = task complexity multiplier from 1.0 to 3.0.
- G_conflict = naive conflict/drift penalty from 0 to 3 iterations.

Token estimates:
T_naive = ceil(B_raw / 4) + T_prompt
T_env = T_prompt + ceil(B_query / 4) + T_receipt + T_overhead
Token_Saved = max(T_naive - T_env, 0)
Token_Saved_% = round(100 * Token_Saved / max(T_naive, 1), 2)

Iteration estimates:
I_naive = max(1, ceil((T_naive / C_eff) * R_complexity) + G_conflict)
I_env = max(1, ceil((T_env / C_eff) * R_complexity))
Iteration_Saved = max(I_naive - I_env, 0)
Iteration_Saved_% = round(100 * Iteration_Saved / max(I_naive, 1), 2)

Important: These are research estimates, not benchmark claims. They compare a naive raw-context-loading counterfactual with package/SQLite selective inspection for the same task. Binary compile artifacts are not treated as semantic text; only their inspectable textual build-analysis footprint is included in B_raw.

## Constant Research Questions Logged For Every Prompt

1. What raw corpus would a naive long-prompt method likely need to load for this task?
2. Which SQLite/package sections did the env method need to query or write instead?
3. What token and iteration savings are estimated from package/SQLite retrieval?
4. Did this prompt preserve Env/UOP/project boundaries and chat-lineage-only write law?
5. What proof artifacts make this turn auditable for professor/research review?

---

## Prompt ENV15.FECDO.P15.S00.T001

- Prompt timestamp: 2026-07-10T13:14:33Z
- Mode/lane: flash_env + code + output + codex_handoff
- Task class: public locked-section package build and Codex handoff generation
- Prompt summary: Build Env15 public Env/UOP/project package, append-only chat lineage, code-index schema, credit-token research ledger, and constrained Codex handoff.
- B_raw estimate: 33,659,405 bytes
- B_query estimate: 650,000 bytes
- T_naive estimate: 8,416,363 tokens
- T_env estimate: 166,711 tokens
- Token_Saved: 8,249,652 tokens
- Token_Saved_%: 98.02%
- I_naive estimate: 204
- I_env estimate: 5
- Iteration_Saved: 199
- Iteration_Saved_%: 97.55%
- Estimate confidence: LOW-MEDIUM
- Evidence basis: source file sizes, V5.9 textual TOC/xref/warning footprint, direct Env14 SQLite schema queries, selected prompt/reference reads, and produced validation artifacts.

### 5 Constant Research Answers

1. A naive route would likely reload the controlling prompts, Env14 package contents/schema, V5.6 audit, Codex/T020 instructions, and the V5.9 textual build-analysis corpus. The estimate excludes the large binary payload from semantic-token claims.
2. The governed route read package pointers, three baseline SQLite schemas, selected governance rows, source hashes, and the V5.9 file-layout/TOC classification. It wrote only the new Env15 build outputs and the allowed chat-lineage bootstrap turn.
3. The formula estimates 98.02% fewer context tokens and 97.55% fewer iterations than the raw-context counterfactual. This is a bounded planning estimate, not a standardized model benchmark.
4. Source Env14 and V5.9 packages were not mutated; the new Env/UOP/project base is read-only and chat_lineage is the only automatic append lane. Other sectors require an explicit named one-turn grant.
5. Auditable proof includes source SHA-256 inventory, SQLite integrity checks, append-only trigger tests, safe-FTS tests, manifests, topology hashes, the validation report, and the exact Codex handoff artifact.


---

## Prompt 2

- Prompt timestamp: 2026-07-10T14:52:04Z
- Mode/lane: flash_env + code + output / Env15 correction
- Task class: baseline-preserving package repair
- Prompt summary: Restore exact Env14 topology bases, append Env15 deltas, restore all project sectors, and regenerate renders.
- B_raw estimate: 3387305
- B_query estimate: 70525
- T_naive estimate: 846956
- T_env estimate: 18961
- Token_Saved: 827995
- Token_Saved_%: 97.76
- I_naive estimate: 17
- I_env estimate: 1
- Iteration_Saved: 16
- Iteration_Saved_%: 94.12
- Estimate confidence: MEDIUM
- Evidence basis: package byte sizes, exact MMD source sizes, SQLite schema inspection, and targeted manifest/sector queries.

### 5 Constant Research Answers

1. A naive route would likely reload both complete packages and prior prompt context; the Env method queried three MMDs, three SQLite schemas, pointers, and sector policy rows.
   The estimate therefore compares full-package raw context against targeted package-state inspection.
2. Exact baseline hash checks, project-sector registry queries, and the MMD no-shrink gate prevented another summary-topology rebuild.
   The active lane was isolated to Env15 package correction plus chat-lineage append.
3. The final package contains base/final MMD hashes, render hashes, SQLite schema inventory, receipts, and a canonical lineage head.
   These artifacts show package-state use rather than reliance on volatile chat memory alone.
4. Env/UOP/project base remained controlled build targets; chat lineage was the only automatic append-write sector.
   All other 13 sectors were restored but require explicit named one-turn mutation and immediate relock.
5. This turn demonstrates measurable context selection, state continuity, and audit proof while correcting an implementation drift.
   The figures are research estimates with assumptions, not standardized benchmark claims.
