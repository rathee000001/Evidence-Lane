# UEPC-ENV15-CODEX-PUBLIC-SECTION-UPDATE-CORRECTED-002

**Mode:** `Codex code mode + full public Env/UOP/Project patch + all-sector preservation + CI/CD verification`  
**Category:** Env15 corrected package integration / Env14 topology base preservation / 14 project sectors / chat-lineage state travel
**Generated:** `2026-07-10T14:52:04Z`

## SUPERSEDE HARD GATE

The supplied Env15 package is authoritative for this patch. The earlier truncated Env15 MMD/public-sector mapping is discarded.

Mandatory corrections:

1. Preserve the full Env14 Env, UOP, and Project MMD source as the base; append Env15 deltas only. Never replace them with summary diagrams.
2. Install and preserve all 14 project sectors from `project/PROJECT_SECTOR_REGISTRY.json`.
3. `chat_lineage` is the only automatic append-write sector. The other 13 sectors remain present/readable and require an explicit user-named one-turn mutation grant, followed by receipt and relock.
4. Import/use `env/`, `uop/`, and `project/` canonical package paths.
5. Preserve the packaged MMD/SVG/PNG files; validate their lock hashes. PNGs must remain byte-preserved in exported packages.
6. Do not change unrelated T020 UI composition. Backend state remains authoritative.

---

# UEPC-ENV15-CODEX-PUBLIC-SECTION-UPDATE-001

**Mode:** `Codex code mode + locked public-section patch + backend-authoritative wiring + CI/CD verification`  
**Category:** SQLite Brain Builder Env15 public package support / chat-lineage state travel / code chunk-index lanes / research ledger writer  
**Generated:** `2026-07-10T13:14:33Z`

---

## 0. CONTROLLING COMMAND

You are receiving:

1. `UEPC_ENV15_PUBLIC_LOCKED_SECTION_PACKAGE.zip`
2. this handoff MD
3. the connected SQLite Builder app source/workspace
4. existing T020/current Codex instructions in the workspace, if present

Read the Env15 package first. Verify ZIP CRC, package class, manifests, `.uepc_env`, `.uepc_profile`, `.uepc_project`, all four SQLite schemas, public laws, chat-lineage schema/triggers, and Codex expected file map before editing code.

This is a **public package-section update only**. This is a public section update only. Do not perform a full UI rebuild. Preserve the current T020 visual shell, source-intake tray, Google Flow layout, backend authority, and installer approval gate. The current T020 prompt remains the visual/source-intake execution posture; this handoff adds Env15 package support and state-travel/code-index behavior only.

---

## 1. ABSOLUTE PATCH SCOPE

Allowed app changes are limited to code needed for:

- importing/verifying Env15 public package;
- mounting public Env/UOP/project base read-only;
- opening `chat_lineage` as the only automatic append-write lane;
- exact prompt/visible-response/file-link capture;
- two-phase PREPARE → RESPONSE → COMMIT state travel;
- canonical `lineage_head` resolution;
- read-only audit write suppression;
- legacy older-Env active-project carry-forward into chat lineage;
- `credit_token_estimate_comparison.md` append writer;
- code snapshot / Git lineage chunk-index schema and ingestion;
- safe FTS query wrapper;
- tests, receipts, manifests, and reports for these changes.

Forbidden unless explicitly required by one of the allowed changes:

- redesigning the T020 UI shell;
- changing unrelated components, pages, routes, modules, or visual placement;
- adding model connectors;
- rebuilding M-Loader as a page;
- persisting GitHub tokens;
- faking backend state in the frontend;
- compiling an installer before the existing visual approval gate;
- autonomous deployment or Git push.

---

## 2. REQUIRED READ ORDER

1. Env15 package `FLASH_ME_FIRST_PUBLIC_ENV15.md`.
2. `.uepc_env`, `.uepc_profile`, `.uepc_project`.
3. `manifests/PUBLIC_SECTION_LOCK_REGISTRY.json`.
4. `manifests/CODE_CHUNK_INDEX_SCHEMA_CONTRACT.json`.
5. `project/sectors/chat_lineage/chat_lineage_schema.md` and SQLite schema.
6. `project/sectors/chat_lineage/credit_token_estimate_comparison.md`.
7. Existing current Codex prompt and T020 controlling prompt in the app workspace.
8. Existing backend worker/bridge and package import/export code.
9. Existing tests and reports.

Create before coding:

- `reports/ENV15_CODEX_SOURCE_READING_LEDGER.md`
- `reports/ENV15_PUBLIC_SECTION_REQUIREMENT_MATRIX.md`
- `reports/ENV15_PUBLIC_SECTION_PATCH_MAP.md`
- `reports/ENV15_OPEN_LOOP_REGISTER.md`

---

## 3. BACKEND AUTHORITY LAW

The Python/SQLite backend is authoritative. The frontend may invoke commands and render returned state but must not fabricate:

- package validation;
- source registration;
- lineage state;
- prompt/response persistence;
- topology existence;
- token estimates;
- output paths;
- receipts or build success.

Keep existing worker commands. Add minimal commands only if missing, such as:

```text
publicPackage.importEnv15
publicPackage.validateEnv15
chatLineage.prepareTurn
chatLineage.commitTurn
chatLineage.resolveHead
chatLineage.carryForwardLegacyProject
chatLineage.searchSafe
researchLedger.appendCreditTokenEstimate
```

Document command deltas in `reports/ENV15_WORKER_COMMAND_DELTA.md`.

---

## 4. READ/WRITE ENFORCEMENT

Runtime connection policy:

```text
public_env/env_public.sqlite = mode=ro&immutable=1
public_uop/uop_public_governance.sqlite = mode=ro&immutable=1
public_project/project_template.sqlite = mode=ro&immutable=1
project/sectors/chat_lineage/chat_lineage_sector_v001.sqlite = read/write append-only
```

All generated/populated project sectors remain read-only by default. A user must explicitly name a target sector and authorize a one-turn mutation. Record the grant in chat lineage and relock immediately after commit.

`WRITEBACK_POLICY`:

- `AUTO`: chat lineage PREPARE and COMMIT are mandatory.
- `DEFERRED`: preserve pending state without package commit if implemented.
- `DISABLED_READ_ONLY_AUDIT`: no package write; output `WRITEBACK_SKIPPED_BY_USER_READ_ONLY_GATE`.

Do not write normal turn data into Env or UOP.

---

## 5. EXACT TURN STATE TRAVEL

Implement exact fields from the package schema:

- `prompt_raw_exact`
- `prompt_normalized_summary`
- `response_raw_visible_exact`
- `response_summary`
- `visible_reasoning_summary` only
- exact entry/exit receipts
- file/link metadata: display/original name, stable file ID, URI, package-relative path, MIME, size, SHA-256, direction, availability, ephemeral state
- gate/operator/mode rows
- previous/current state hash
- monotonic turn sequence
- append-only lineage head history

Never store hidden chain-of-thought.

Two-phase protocol:

1. PREPARE exact prompt + files + entry slip and commit.
2. Execute task and form visible answer.
3. COMMIT exact visible answer + summaries + links + exit slip + gate/operator rows + hash chain + new lineage head.

Preserve `PREPARED_NOT_COMMITTED` on failure.

Use the package's SQLite triggers and add application-level enforcement. Tests must prove UPDATE/DELETE/duplicate/non-monotonic writes fail.

---

## 6. LEGACY ENV CARRY-FORWARD

On flash/import, scan for an older Env package already active in the workspace/session:

1. Read old `.uepc_project` and active write-section pointer.
2. Never mutate the old package.
3. Copy the active project-writing state into the new package/workspace under:
   `project/sectors/chat_lineage/legacy_project_carry_forward/`
4. Register it as:
   `LEGACY_PROJECT_SECTION_CARRY_FORWARD | PROJECT_HISTORY_SOURCE | ALLOWED_RW_CHAT_LINEAGE_MIRROR | NOT_ENV_LAW | NOT_UOP_TRUTH`
5. If none exists, record `NO_LEGACY_ENV_PRESENT`.

This behavior is active from the first flash prompt.

---

## 7. CREDIT TOKEN ESTIMATE LEDGER WRITER

Implement an append-only Markdown writer for:

`project/sectors/chat_lineage/credit_token_estimate_comparison.md`

Do not store per-prompt estimates in SQLite. The file keeps the formula and five constant research questions at the top. For each AUTO prompt, append the indexed task estimate and five maximum-two-line answers. Do not append in read-only audit mode.

Treat estimates as research planning estimates, never benchmark/ROI facts. Preserve the formula and format from the package exactly.

---

## 8. CODE CHUNK / INDEX SUPPORT

Preserve separate layers:

```text
Code Snapshot Layer = current working tree
Git Lineage Layer = commit/history evolution
```

GitHub:
- full history by default;
- optional branch/tag;
- token memory-only and masked;
- never persist token in settings, DB, receipt, log, error, or lineage;
- use existing repo/pull behavior where present.

Local code:
- folder picker;
- `.git` present → snapshot + lineage;
- no `.git` → snapshot only.

Structured text artifacts to study: JSON/JSONL/CSV/TSV/YAML/XML/HTML/SVG/MMD/MD/TXT/IPYNB/SQL/TOML/INI/env.example/config/CI/Dockerfile.

Binary/visual assets: image/video/GLB/GLTF/large binary/executable metadata only: path, size, hash, extension, lane, relation, review state.

Populate/use the package schema contract for files, chunks, symbols, imports, routes/APIs, config/build/test records, commits, file changes, diffs, structured artifacts, binary metadata, and topology edges.

Do not change the existing project-master-topology contract unnecessarily.

---

## 9. SAFE FTS

Use parameter binding and the package safe wrapper. Quote/escape punctuation, periods, hyphens, paths, and FTS reserved operators. Tests must cover:

```text
V5.5
deep-ml
C:\path\file.py
project/sectors/chat_lineage
AND OR NOT
```

Raw user strings must never be concatenated into `MATCH` SQL.

---

## 10. TEST / CI-CD LOOP

Run controlled local validation only:

```powershell
python -m py_compile <changed Python files>
python -m pytest tests
npm run build
cargo build --release
npm run tauri -- build --no-bundle
```

Use only applicable commands based on the connected app. Do not claim PASS for a command not run; mark `NOT_APPLICABLE` or `TOOL_BLOCKED`.

Required tests:

1. Env/UOP/project DBs opened read-only.
2. Normal turn changes only chat-lineage DB/ledger/receipts/manifests allowed by the app workflow.
3. Read-only audit changes nothing.
4. PREPARE commits before simulated response.
5. COMMIT stores exact visible prompt/response and advances one canonical head.
6. UPDATE/DELETE/duplicate/non-monotonic writes fail.
7. File-link metadata is complete.
8. Legacy carry-forward copies without old-package mutation.
9. No older Env records `NO_LEGACY_ENV_PRESENT`.
10. Safe FTS punctuation cases pass.
11. Credit ledger appends in AUTO and skips in read-only audit.
12. GitHub token does not persist.
13. Local code without Git produces snapshot only.
14. Local code with Git produces snapshot + lineage.
15. Structured artifacts are chunked; binary assets metadata-only.
16. Existing T020 visual shell remains unchanged unless a minimal package-status control is essential.
17. Installer remains skipped until existing visual approval gate.

Run a before/after write-boundary diff and prove unrelated files/modules were not changed.

---

## 11. REQUIRED REPORTS

Create:

- `reports/ENV15_CODEX_PUBLIC_SECTION_UPDATE_REPORT.md`
- `reports/ENV15_PUBLIC_SECTION_LOCK_VALIDATION.md`
- `reports/ENV15_CHAT_LINEAGE_VALIDATION.md`
- `reports/ENV15_CODE_CHUNK_INDEX_VALIDATION.md`
- `reports/ENV15_CREDIT_TOKEN_LEDGER_VALIDATION.md`
- `reports/ENV15_UNRELATED_FILE_DIFF_AUDIT.md`

Report exact files changed, tests run, pass/warn/blocked states, and remaining gaps.

---

## 12. STOP RULES

Stop with a blocker report if:

- Env15 package cannot be inspected;
- app source is not connected;
- patch scope cannot be isolated;
- backend authority would be replaced by frontend fake state;
- Env/UOP/project base cannot be kept read-only;
- append-only chat lineage cannot be enforced or honestly marked as a gap;
- tests fail;
- token could be persisted;
- change would require unrelated UI rebuild;
- installer compilation would violate the current approval gate.

Do not silently widen scope.

---

## 13. FINAL STATUS

Use one:

```text
ENV15_PUBLIC_SECTION_PATCH_READY_INSTALLER_UNCHANGED
BLOCKED_ENV15_PACKAGE_INSPECTION
BLOCKED_APP_SOURCE_NOT_CONNECTED
BLOCKED_PUBLIC_SECTION_SCOPE_NOT_ISOLATED
BLOCKED_CHAT_LINEAGE_ENFORCEMENT
BLOCKED_CODE_INDEX_DELTA
BLOCKED_TEST_FAILURE
```

Final answer must include:

- files read;
- files changed;
- package support summary;
- chat-lineage summary;
- legacy carry-forward summary;
- credit-ledger summary;
- code-index summary;
- tests run;
- report paths;
- final status.
