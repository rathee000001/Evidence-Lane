# Chat-Lineage Append-Only Law

- Default writeback policy: AUTO.
- Read-only/analysis/discussion/no-change requests may select DISABLED_READ_ONLY_AUDIT.
- PREPARE exact prompt and files before reasoning.
- COMMIT exact visible response, summary, visible reasoning summary, receipts, gates/operators, links, and hashes after response.
- Hidden chain-of-thought is never stored.
- Committed records reject UPDATE and DELETE.
- Turn sequences and lineage heads are monotonic.
- Canonical operational paths are package-relative.


## Env15 full-sector preservation correction (2026-07-10T14:52:04Z)

All 14 universal project sectors are present. Chat lineage is the only automatic append-write sector. The other 13 sectors remain readable and become writable only under an explicit user-named one-turn mutation grant, followed by immediate relock and a mutation receipt.
